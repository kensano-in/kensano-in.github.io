import { useState, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useWebSocket } from '@/hooks/useWebSocket';
import { LoginPage } from '@/sections/LoginPage';
import { RegisterPage } from '@/sections/RegisterPage';
import { ChatLayout } from '@/sections/ChatLayout';
import type { Message, TypingIndicator } from '@/types';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

function App() {
  const [currentView, setCurrentView] = useState<'login' | 'register' | 'chat'>('login');
  const [unreadCounts, setUnreadCounts] = useState<Record<string, number>>({});
  const [typingIndicators, setTypingIndicators] = useState<Record<string, TypingIndicator>>({});

  const { user, token, isAuthenticated, isLoading, login, register, logout } = useAuth();

  // Handle incoming WebSocket messages
  const handleMessage = useCallback((message: Message) => {
    // Show notification if message is from someone else
    if (message.sender_id !== user?.user_id) {
      toast.message(`New message from ${message.sender?.display_name || 'Someone'}`, {
        description: message.content.substring(0, 50) + (message.content.length > 50 ? '...' : ''),
      });
      
      // Update unread count
      setUnreadCounts(prev => ({
        ...prev,
        [message.chat_id]: (prev[message.chat_id] || 0) + 1,
      }));
    }
  }, [user?.user_id]);

  const handleTyping = useCallback((typing: TypingIndicator) => {
    setTypingIndicators(prev => ({
      ...prev,
      [typing.chat_id]: typing,
    }));

    // Clear typing indicator after 5 seconds
    setTimeout(() => {
      setTypingIndicators(prev => {
        const next = { ...prev };
        delete next[typing.chat_id];
        return next;
      });
    }, 5000);
  }, []);

  const handleReadReceipt = useCallback((chatId: string, messageId: string, userId: string) => {
    // Update message read status in UI
    console.log('Read receipt:', { chatId, messageId, userId });
  }, []);

  const handleWebSocketError = useCallback((error: string) => {
    toast.error('Connection error', { description: error });
  }, []);

  const { isConnected, sendMessage, sendTyping, sendReadReceipt } = useWebSocket(
    token,
    handleMessage,
    handleTyping,
    handleReadReceipt,
    handleWebSocketError
  );

  const handleLogin = async (username: string, password: string) => {
    const success = await login(username, password);
    if (success) {
      setCurrentView('chat');
      toast.success('Welcome back!');
    } else {
      toast.error('Login failed', { description: 'Invalid username or password' });
    }
  };

  const handleRegister = async (
    username: string,
    email: string,
    password: string,
    displayName: string
  ) => {
    const success = await register(username, email, password, displayName);
    if (success) {
      setCurrentView('chat');
      toast.success('Account created successfully!');
    } else {
      toast.error('Registration failed');
    }
  };

  const handleLogout = async () => {
    await logout();
    setCurrentView('login');
    toast.success('Logged out successfully');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <>
      {currentView === 'login' && (
        <LoginPage
          onLogin={handleLogin}
          onNavigateToRegister={() => setCurrentView('register')}
        />
      )}

      {currentView === 'register' && (
        <RegisterPage
          onRegister={handleRegister}
          onNavigateToLogin={() => setCurrentView('login')}
        />
      )}

      {currentView === 'chat' && isAuthenticated && user && (
        <ChatLayout
          user={user}
          isConnected={isConnected}
          unreadCounts={unreadCounts}
          typingIndicators={typingIndicators}
          onSendMessage={sendMessage}
          onSendTyping={sendTyping}
          onSendReadReceipt={sendReadReceipt}
          onLogout={handleLogout}
          onClearUnread={(chatId) => {
            setUnreadCounts(prev => ({ ...prev, [chatId]: 0 }));
          }}
        />
      )}

      <Toaster position="top-right" />
    </>
  );
}

export default App;
