// Types for Messaging Platform

export interface User {
  user_id: string;
  username: string;
  email: string;
  phone?: string;
  display_name: string;
  avatar_url?: string;
  status: 'active' | 'away' | 'offline' | 'deleted';
  last_seen?: string;
  is_verified: boolean;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  user_id: string;
  username: string;
}

export interface Chat {
  chat_id: string;
  chat_type: 'direct' | 'group' | 'channel';
  title: string;
  created_by: string;
  created_at: string;
  updated_at: string;
  participants?: ChatParticipant[];
  unread_count?: number;
  last_message?: Message;
}

export interface ChatParticipant {
  user_id: string;
  role: 'admin' | 'member';
  joined_at: string;
  last_read_message_id?: string;
  user?: User;
}

export interface Message {
  message_id: string;
  chat_id: string;
  sender_id: string;
  sender?: User;
  message_type: 'text' | 'image' | 'video' | 'file' | 'audio';
  content: string;
  created_at: string;
  edited_at?: string;
  is_deleted: boolean;
  reply_to?: string;
  reply_to_message?: Message;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
}

export interface Contact {
  contact_id: string;
  user_id: string;
  contact_user_id: string;
  display_name?: string;
  is_blocked: boolean;
  contact_user?: User;
}

export interface PrivacySettings {
  setting_id: string;
  user_id: string;
  last_seen_visibility: 'everyone' | 'contacts' | 'nobody';
  profile_photo_visibility: 'everyone' | 'contacts' | 'nobody';
  phone_visibility: 'everyone' | 'contacts' | 'nobody';
  add_by_phone: boolean;
}

export interface TypingIndicator {
  chat_id: string;
  user_id: string;
  username: string;
  action: 'typing' | 'stopped';
}

export interface WebSocketMessage {
  type: 'message' | 'typing' | 'presence' | 'read_receipt' | 'error' | 'pong';
  payload: any;
  timestamp?: string;
}

export interface SendMessageRequest {
  chat_id: string;
  content: string;
  message_type?: string;
  reply_to?: string;
}
