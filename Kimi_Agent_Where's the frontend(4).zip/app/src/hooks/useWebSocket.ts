import { useState, useEffect, useRef, useCallback } from 'react';
import type { WebSocketMessage, Message, TypingIndicator } from '@/types';

const WS_BASE_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:8084';

interface WebSocketState {
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
}

interface UseWebSocketReturn extends WebSocketState {
  sendMessage: (chatId: string, content: string, replyTo?: string) => void;
  sendTyping: (chatId: string, action: 'typing' | 'stopped') => void;
  sendReadReceipt: (chatId: string, messageId: string) => void;
  sendPing: () => void;
}

export function useWebSocket(
  token: string | null,
  onMessage: (message: Message) => void,
  onTyping: (typing: TypingIndicator) => void,
  onReadReceipt: (chatId: string, messageId: string, userId: string) => void,
  onError: (error: string) => void
): UseWebSocketReturn {
  const [state, setState] = useState<WebSocketState>({
    isConnected: false,
    isConnecting: false,
    error: null,
  });

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pingIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const connect = useCallback(() => {
    if (!token || wsRef.current?.readyState === WebSocket.OPEN) return;

    setState(prev => ({ ...prev, isConnecting: true, error: null }));

    const ws = new WebSocket(`${WS_BASE_URL}/ws?token=${token}&device_id=web`);

    ws.onopen = () => {
      console.log('WebSocket connected');
      setState({
        isConnected: true,
        isConnecting: false,
        error: null,
      });

      // Start ping interval
      pingIntervalRef.current = setInterval(() => {
        sendPing();
      }, 30000);
    };

    ws.onmessage = (event) => {
      try {
        const data: WebSocketMessage = JSON.parse(event.data);
        
        switch (data.type) {
          case 'message':
            onMessage(data.payload as Message);
            break;
          case 'typing':
            onTyping(data.payload as TypingIndicator);
            break;
          case 'read_receipt':
            const { chat_id, message_id, user_id } = data.payload;
            onReadReceipt(chat_id, message_id, user_id);
            break;
          case 'error':
            onError(data.payload.error || 'Unknown error');
            break;
          case 'pong':
            // Pong received, connection is alive
            break;
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.onclose = (event) => {
      console.log('WebSocket disconnected:', event.code, event.reason);
      setState({
        isConnected: false,
        isConnecting: false,
        error: 'Connection lost',
      });

      // Clear ping interval
      if (pingIntervalRef.current) {
        clearInterval(pingIntervalRef.current);
        pingIntervalRef.current = null;
      }

      // Attempt reconnection after 3 seconds
      if (token) {
        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
        }, 3000);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setState(prev => ({
        ...prev,
        isConnecting: false,
        error: 'Connection error',
      }));
    };

    wsRef.current = ws;
  }, [token]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }

    if (pingIntervalRef.current) {
      clearInterval(pingIntervalRef.current);
      pingIntervalRef.current = null;
    }

    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, []);

  // Connect when token is available
  useEffect(() => {
    if (token) {
      connect();
    } else {
      disconnect();
    }

    return () => {
      disconnect();
    };
  }, [token, connect, disconnect]);

  const sendMessage = useCallback((chatId: string, content: string, replyTo?: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'message',
        payload: {
          chat_id: chatId,
          content,
          message_type: 'text',
          reply_to: replyTo,
        },
      }));
    }
  }, []);

  const sendTyping = useCallback((chatId: string, action: 'typing' | 'stopped') => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'typing',
        payload: {
          chat_id: chatId,
          action,
        },
      }));
    }
  }, []);

  const sendReadReceipt = useCallback((chatId: string, messageId: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'read_receipt',
        payload: {
          chat_id: chatId,
          message_id: messageId,
        },
      }));
    }
  }, []);

  const sendPing = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({
        type: 'ping',
        payload: {},
      }));
    }
  }, []);

  return {
    ...state,
    sendMessage,
    sendTyping,
    sendReadReceipt,
    sendPing,
  };
}
