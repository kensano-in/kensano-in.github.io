import { useState, useEffect, useCallback } from 'react';
import type { Chat, Message, SendMessageRequest } from '@/types';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

function getAuthHeaders() {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    'Authorization': token ? `Bearer ${token}` : '',
  };
}

export function useChats() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchChats = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/chats`, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const data = await response.json();
        setChats(data.chats || []);
      } else {
        setError('Failed to fetch chats');
      }
    } catch (err) {
      setError('Network error');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchChats();
  }, [fetchChats]);

  const createChat = useCallback(async (chatType: string, title: string, members: string[]): Promise<Chat | null> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/chats`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ chat_type: chatType, title, members }),
      });

      if (response.ok) {
        const newChat = await response.json();
        setChats(prev => [newChat, ...prev]);
        return newChat;
      }
      return null;
    } catch (err) {
      console.error('Create chat error:', err);
      return null;
    }
  }, []);

  const getChat = useCallback(async (chatId: string): Promise<Chat | null> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/chats/${chatId}`, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        return await response.json();
      }
      return null;
    } catch (err) {
      console.error('Get chat error:', err);
      return null;
    }
  }, []);

  return {
    chats,
    isLoading,
    error,
    fetchChats,
    createChat,
    getChat,
  };
}

export function useMessages(chatId: string | null) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);

  const fetchMessages = useCallback(async (before?: string) => {
    if (!chatId) return;

    setIsLoading(true);

    try {
      let url = `${API_BASE_URL}/api/v1/chats/${chatId}/messages?limit=50`;
      if (before) {
        url += `&before=${before}`;
      }

      const response = await fetch(url, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const data = await response.json();
        const newMessages = data.messages || [];
        
        if (before) {
          setMessages(prev => [...prev, ...newMessages]);
        } else {
          setMessages(newMessages);
        }
        
        setHasMore(newMessages.length === 50);
      }
    } catch (err) {
      console.error('Fetch messages error:', err);
    } finally {
      setIsLoading(false);
    }
  }, [chatId]);

  const sendMessage = useCallback(async (content: string, replyTo?: string): Promise<Message | null> => {
    if (!chatId) return null;

    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/chats/${chatId}/messages`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ content, message_type: 'text', reply_to: replyTo } as SendMessageRequest),
      });

      if (response.ok) {
        const newMessage = await response.json();
        setMessages(prev => [newMessage, ...prev]);
        return newMessage;
      }
      return null;
    } catch (err) {
      console.error('Send message error:', err);
      return null;
    }
  }, [chatId]);

  const addMessage = useCallback((message: Message) => {
    setMessages(prev => {
      // Check if message already exists
      const exists = prev.some(m => m.message_id === message.message_id);
      if (exists) return prev;
      return [message, ...prev];
    });
  }, []);

  const markAsRead = useCallback(async (messageId: string) => {
    if (!chatId) return;

    try {
      await fetch(`${API_BASE_URL}/api/v1/chats/${chatId}/messages/${messageId}/read`, {
        method: 'POST',
        headers: getAuthHeaders(),
      });
    } catch (err) {
      console.error('Mark as read error:', err);
    }
  }, [chatId]);

  return {
    messages,
    isLoading,
    hasMore,
    fetchMessages,
    sendMessage,
    addMessage,
    markAsRead,
  };
}

export function useContacts() {
  const [contacts, setContacts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchContacts = useCallback(async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/contacts`, {
        headers: getAuthHeaders(),
      });

      if (response.ok) {
        const data = await response.json();
        setContacts(data.contacts || []);
      }
    } catch (err) {
      console.error('Fetch contacts error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const addContact = useCallback(async (contactUserId: string, displayName?: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/contacts`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ contact_user_id: contactUserId, display_name: displayName }),
      });

      if (response.ok) {
        const newContact = await response.json();
        setContacts(prev => [...prev, newContact]);
        return true;
      }
      return false;
    } catch (err) {
      console.error('Add contact error:', err);
      return false;
    }
  }, []);

  const searchUsers = useCallback(async (query: string): Promise<any[]> => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/users/search`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify({ query, limit: 20 }),
      });

      if (response.ok) {
        const data = await response.json();
        return data.users || [];
      }
      return [];
    } catch (err) {
      console.error('Search users error:', err);
      return [];
    }
  }, []);

  return {
    contacts,
    isLoading,
    fetchContacts,
    addContact,
    searchUsers,
  };
}
