import { useState, useEffect, useRef } from 'react';
import type { User, Chat, TypingIndicator } from '@/types';
import { useChats, useMessages, useContacts } from '@/hooks/useChats';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  MessageSquare,
  Send,
  MoreVertical,
  LogOut,
  User as UserIcon,
  Search,
  Plus,
  Phone,
  Video,
  Paperclip,
  Smile,
  Check,
  CheckCheck,
  Settings,
  Users,
} from 'lucide-react';

interface ChatLayoutProps {
  user: User;
  isConnected: boolean;
  unreadCounts: Record<string, number>;
  typingIndicators: Record<string, TypingIndicator>;
  onSendMessage: (chatId: string, content: string, replyTo?: string) => void;
  onSendTyping: (chatId: string, action: 'typing' | 'stopped') => void;
  onSendReadReceipt: (chatId: string, messageId: string) => void;
  onLogout: () => void;
  onClearUnread: (chatId: string) => void;
}

export function ChatLayout({
  user,
  isConnected,
  unreadCounts,
  typingIndicators,
  onSendMessage,
  onSendTyping,
  onSendReadReceipt,
  onLogout,
  onClearUnread,
}: ChatLayoutProps) {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewChatDialog, setShowNewChatDialog] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { chats, isLoading: chatsLoading, createChat } = useChats();
  useContacts();
  const {
    messages,
    isLoading: messagesLoading,
    sendMessage: sendMessageApi,
  } = useMessages(selectedChatId);

  const selectedChat = chats.find(c => c.chat_id === selectedChatId);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Mark messages as read when chat is selected
  useEffect(() => {
    if (selectedChatId && messages.length > 0) {
      const unreadMessage = messages.find(m => m.sender_id !== user.user_id);
      if (unreadMessage) {
        onSendReadReceipt(selectedChatId, unreadMessage.message_id);
        onClearUnread(selectedChatId);
      }
    }
  }, [selectedChatId, messages, user.user_id]);

  const handleSendMessage = async () => {
    if (!messageInput.trim() || !selectedChatId) return;

    const content = messageInput.trim();
    setMessageInput('');

    // Send via WebSocket for real-time delivery
    onSendMessage(selectedChatId, content);

    // Also send via API for persistence
    await sendMessageApi(content);

    // Stop typing indicator
    onSendTyping(selectedChatId, 'stopped');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageInput(e.target.value);

    // Send typing indicator
    if (selectedChatId) {
      onSendTyping(selectedChatId, 'typing');

      // Clear previous timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }

      // Stop typing after 3 seconds of inactivity
      typingTimeoutRef.current = setTimeout(() => {
        onSendTyping(selectedChatId, 'stopped');
      }, 3000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const filteredChats = chats.filter(chat =>
    chat.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className="w-80 border-r flex flex-col">
        {/* Header */}
        <div className="p-4 border-b">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  {getInitials(user.display_name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user.display_name}</p>
                <div className="flex items-center gap-1">
                  <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
                  <span className="text-xs text-muted-foreground">
                    {isConnected ? 'Online' : 'Connecting...'}
                  </span>
                </div>
              </div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <UserIcon className="w-4 h-4 mr-2" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onLogout} className="text-destructive">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <Dialog open={showNewChatDialog} onOpenChange={setShowNewChatDialog}>
            <DialogTrigger asChild>
              <Button className="w-full" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                New Chat
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>New Chat</DialogTitle>
              </DialogHeader>
              <NewChatDialog onCreateChat={createChat} onClose={() => setShowNewChatDialog(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {/* Chat List */}
        <ScrollArea className="flex-1">
          {chatsLoading ? (
            <div className="p-4 text-center text-muted-foreground">Loading chats...</div>
          ) : filteredChats.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground">No chats found</div>
          ) : (
            filteredChats.map((chat) => {
              const unreadCount = unreadCounts[chat.chat_id] || 0;
              const isSelected = selectedChatId === chat.chat_id;

              return (
                <button
                  key={chat.chat_id}
                  onClick={() => {
                    setSelectedChatId(chat.chat_id);
                    onClearUnread(chat.chat_id);
                  }}
                  className={`w-full p-4 flex items-center gap-3 hover:bg-accent transition-colors text-left ${
                    isSelected ? 'bg-accent' : ''
                  }`}
                >
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-secondary">
                      {getInitials(chat.title)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">{chat.title}</p>
                      {chat.last_message && (
                        <span className="text-xs text-muted-foreground">
                          {formatTime(chat.last_message.created_at)}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-muted-foreground truncate">
                        {chat.last_message?.content || 'No messages yet'}
                      </p>
                      {unreadCount > 0 && (
                        <span className="bg-primary text-primary-foreground text-xs rounded-full px-2 py-0.5">
                          {unreadCount}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </ScrollArea>
      </div>

      {/* Chat Area */}
      {selectedChat ? (
        <div className="flex-1 flex flex-col">
          {/* Chat Header */}
          <div className="p-4 border-b flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-secondary">
                  {getInitials(selectedChat.title)}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{selectedChat.title}</p>
                {typingIndicators[selectedChat.chat_id] ? (
                  <p className="text-xs text-green-600">typing...</p>
                ) : (
                  <p className="text-xs text-muted-foreground">
                    {selectedChat.participants?.length || 2} members
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon">
                <Phone className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Video className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Messages */}
          <ScrollArea className="flex-1 p-4">
            {messagesLoading ? (
              <div className="text-center text-muted-foreground">Loading messages...</div>
            ) : messages.length === 0 ? (
              <div className="text-center text-muted-foreground">No messages yet</div>
            ) : (
              <div className="space-y-4">
                {[...messages].reverse().map((message, index) => {
                  const isOwn = message.sender_id === user.user_id;
                  const showDate =
                    index === 0 ||
                    formatDate(message.created_at) !==
                      formatDate([...messages].reverse()[index - 1]?.created_at);

                  return (
                    <div key={message.message_id}>
                      {showDate && (
                        <div className="flex justify-center my-4">
                          <span className="text-xs text-muted-foreground bg-muted px-3 py-1 rounded-full">
                            {formatDate(message.created_at)}
                          </span>
                        </div>
                      )}
                      <div
                        className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] ${
                            isOwn
                              ? 'bg-primary text-primary-foreground rounded-2xl rounded-tr-sm'
                              : 'bg-muted rounded-2xl rounded-tl-sm'
                          } px-4 py-2`}
                        >
                          {!isOwn && (
                            <p className="text-xs font-medium mb-1 opacity-70">
                              {message.sender?.display_name || 'Unknown'}
                            </p>
                          )}
                          <p className="text-sm">{message.content}</p>
                          <div className="flex items-center justify-end gap-1 mt-1">
                            <span className="text-xs opacity-70">
                              {formatTime(message.created_at)}
                            </span>
                            {isOwn && (
                              message.status === 'read' ? (
                                <CheckCheck className="w-3 h-3 opacity-70" />
                              ) : (
                                <Check className="w-3 h-3 opacity-70" />
                              )
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>

          {/* Message Input */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon">
                <Paperclip className="w-5 h-5" />
              </Button>
              <Input
                placeholder="Type a message..."
                value={messageInput}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                className="flex-1"
              />
              <Button variant="ghost" size="icon">
                <Smile className="w-5 h-5" />
              </Button>
              <Button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                size="icon"
              >
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-10 h-10 text-muted-foreground" />
            </div>
            <h3 className="text-xl font-medium mb-2">Select a chat</h3>
            <p className="text-muted-foreground">
              Choose a conversation from the sidebar to start messaging
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

// New Chat Dialog Component
function NewChatDialog({
  onCreateChat,
  onClose,
}: {
  onCreateChat: (type: string, title: string, members: string[]) => Promise<Chat | null>;
  onClose: () => void;
}) {
  const [step, setStep] = useState<'type' | 'details'>('type');
  const [chatType, setChatType] = useState<'direct' | 'group'>('direct');
  const [title, setTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<User[]>([]);
  const [isCreating, setIsCreating] = useState(false);

  const { searchUsers } = useContacts();

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      const results = await searchUsers(query);
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const handleCreate = async () => {
    if (selectedUsers.length === 0) return;

    setIsCreating(true);
    const chatTitle = chatType === 'group' ? title : selectedUsers[0].display_name;
    const memberIds = selectedUsers.map(u => u.user_id);

    const chat = await onCreateChat(chatType, chatTitle, memberIds);
    if (chat) {
      onClose();
    }
    setIsCreating(false);
  };

  const toggleUser = (user: User) => {
    if (chatType === 'direct') {
      setSelectedUsers([user]);
    } else {
      setSelectedUsers(prev => {
        const exists = prev.find(u => u.user_id === user.user_id);
        if (exists) {
          return prev.filter(u => u.user_id !== user.user_id);
        }
        return [...prev, user];
      });
    }
  };

  if (step === 'type') {
    return (
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">What type of chat do you want to create?</p>
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => {
              setChatType('direct');
              setStep('details');
            }}
            className="p-4 border rounded-lg hover:bg-accent transition-colors text-center"
          >
            <UserIcon className="w-8 h-8 mx-auto mb-2" />
            <p className="font-medium">Direct Message</p>
            <p className="text-xs text-muted-foreground">Chat with one person</p>
          </button>
          <button
            onClick={() => {
              setChatType('group');
              setStep('details');
            }}
            className="p-4 border rounded-lg hover:bg-accent transition-colors text-center"
          >
            <Users className="w-8 h-8 mx-auto mb-2" />
            <p className="font-medium">Group Chat</p>
            <p className="text-xs text-muted-foreground">Chat with multiple people</p>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {chatType === 'group' && (
        <div>
          <label className="text-sm font-medium">Group Name</label>
          <Input
            placeholder="Enter group name"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
        </div>
      )}

      <div>
        <label className="text-sm font-medium">Search Users</label>
        <Input
          placeholder="Search by username or name..."
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
        />
      </div>

      {searchResults.length > 0 && (
        <div className="border rounded-lg max-h-48 overflow-auto">
          {searchResults.map((user) => {
            const isSelected = selectedUsers.find(u => u.user_id === user.user_id);
            return (
              <button
                key={user.user_id}
                onClick={() => toggleUser(user)}
                className={`w-full p-3 flex items-center gap-3 hover:bg-accent transition-colors text-left ${
                  isSelected ? 'bg-accent' : ''
                }`}
              >
                <Avatar className="w-8 h-8">
                  <AvatarFallback>{user.display_name.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="font-medium">{user.display_name}</p>
                  <p className="text-xs text-muted-foreground">@{user.username}</p>
                </div>
                {isSelected && <Check className="w-4 h-4" />}
              </button>
            );
          })}
        </div>
      )}

      {selectedUsers.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedUsers.map((user) => (
            <span
              key={user.user_id}
              className="inline-flex items-center gap-1 bg-primary/10 text-primary px-2 py-1 rounded-full text-sm"
            >
              {user.display_name}
              <button
                onClick={() => toggleUser(user)}
                className="hover:text-destructive"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="flex gap-2">
        <Button variant="outline" onClick={() => setStep('type')} className="flex-1">
          Back
        </Button>
        <Button
          onClick={handleCreate}
          disabled={selectedUsers.length === 0 || (chatType === 'group' && !title) || isCreating}
          className="flex-1"
        >
          {isCreating ? 'Creating...' : 'Create Chat'}
        </Button>
      </div>
    </div>
  );
}
