const t=document.getElementById('themeToggle');if(t){t.onclick=()=>document.body.classList.toggle('light');}
const p=new URLSearchParams(window.location.search).get('title');
if(p){const h=document.getElementById('poemTitle');if(h){h.textContent=p.replace(/-/g,' ');}}
